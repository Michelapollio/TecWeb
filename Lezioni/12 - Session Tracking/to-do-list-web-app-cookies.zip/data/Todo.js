export class Todo {
  constructor(todo, date, username){
    this.todo = todo;
    this.creation_date = date;
    this.username = username;
  }
}