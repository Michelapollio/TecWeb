export default () => /*html*/`
    <h1>About</h1>
    <p>This is a single page app. Navigating to different pages does not trigger a full-page reload!</p>
    <click-counter></click-counter>
`;