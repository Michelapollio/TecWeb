export default () => /*html*/`
    <h1>Web Technologies</h1>
    <p>Web Technologies is a 6 ETCS course introducing students to design and development of modern web apps.</p>
`;