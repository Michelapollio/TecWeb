export default () => /*html*/`
  To-do list SPA with plain JavaScript.
`;