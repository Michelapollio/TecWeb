export default () => /*html*/`
    <h1>Home</h1>
    <p>Simple click counter</p>
    <to-do-list></to-do-list>
    <app-footer></app-footer>
`;