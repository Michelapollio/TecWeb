import "../components/counter.js";

export default () => /*html*/`
    <h1>Home</h1>
    <p>Simple click counter</p>
    <click-counter></click-counter>
`;