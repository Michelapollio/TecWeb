import "../components/todolist.js";

export default () => /*html*/`
    <h1>To-do List</h1>
    <p>Now implemented as a sleek SPA with plain JavaScript!</p>
    <todo-list></todo-list>
    <app-footer></app-footer>
`;