export default () => /*html*/`
    <h1>Contact</h1>
    <p>Consectetur in vitae totam nulla reprehenderit est earum debitis quam laboriosam.</p>
`;