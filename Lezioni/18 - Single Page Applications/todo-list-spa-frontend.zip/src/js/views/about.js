export default () => /*html*/`
    <h1>About</h1>
    <p>This is a simple implementation of To-do list as a Single Page App.</p>
    <p>
    This app is meant as a didactic example to showcase SPAs within the 
    Web Technologies course at the University of Naples Federico II. 
    It is affected by performance issues
    </p>
`;