export interface TodoItem {
  id?: number; 
  todo: string; 
  done?: boolean; 
  UserUserName?: string; 
  createdAt?: Date; 
  updatedAt?: Date;
}
