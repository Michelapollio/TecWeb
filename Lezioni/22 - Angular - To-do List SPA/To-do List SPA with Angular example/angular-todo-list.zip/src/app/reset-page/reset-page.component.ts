import { Component } from '@angular/core';

@Component({
  selector: 'app-reset-page',
  standalone: true,
  imports: [],
  templateUrl: './reset-page.component.html',
  styleUrl: './reset-page.component.scss'
})
export class ResetPageComponent {

}
