export class Todo {
  constructor(todo, date){
    this.todo = todo;
    this.creation_date = date;
  }
}